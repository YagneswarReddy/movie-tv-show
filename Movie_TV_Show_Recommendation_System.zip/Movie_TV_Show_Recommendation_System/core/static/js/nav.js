let logo=document.getElementById('logo')
logo.addEventListener('click', ()=>{
    window.location.href='http://127.0.0.1:8888/home'
})