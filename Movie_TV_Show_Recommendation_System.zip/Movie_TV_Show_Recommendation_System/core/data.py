data_line1=[ 
    {
        'name': 'hidden1','id':'movie1','genre':'Action, Crime & Drama','url':'../static/images/movies/movie1.jpg', 
        'desc':'The fate of a violently contested kingdom hangs on the fraught bond between two friends-turned-foes in this saga of power, bloodshed and betrayal.',
        'director':'Prashanth Neel',
        'streaming':'Netflix',
        'writers':'Sandeep Reddy Bandla, Choudary Hanuman & Prashanth Neel',
        'index':1,
    },
    {
        'name': 'hidden2','id':'movie2','genre':'Romance & Drama','url':'../static/images/movies/movie2.jpg',
        'desc':'Love blooms between a doctor with an uncertain future and a renowned palmist who thought he would never find love. His beliefs are challenged.',
        'director':'K.K. Radhakrishna Kumar',
        'streaming':'Netflix, Prime Video & Zee5',
        'writers':'Abbas Dalal, Hussain Dalal & Madhan Karky',
        'index':2,
     },
    {
        'name': 'hidden3','id':'movie3','genre':'Action & Thriller','url':'../static/images/movies/movie3.jpg',
        'desc':'An undercover cop becomes embroiled in a battle with warring criminals who want to acquire a "black box," their ultimate key to a treasure.',
        'director':'Sujeeth',
        'streaming':'Netflix & Prime Video',
        'writers':'Sujeeth, K.G.R Ashok & Abbas Dalal',
        'index':3,
    },
    {
        'name': 'hidden4','id':'movie4','genre':'Action & Drama','url':'../static/images/movies/movie4.jpg',
        'desc':'A child from the Mahishmati kingdom is raised by tribal people and one day learns about his royal heritage, his fathers bravery in battle and a mission to overthrow the incumbent ruler.',
        'director':'S.S. Rajamouli',
        'streaming':'Netflix, Diney+ Hotstar & Sony Liv',
        'writers':'Vijayendra PrasadS.S, RajamouliC.H & Vijay Kumar',
        'index':4,
    },
    {
        'name': 'hidden5','id':'movie5','genre':'Action & Drama','url':'../static/images/movies/movie5.jpg',
        'desc':'Amarendra Baahubali, the heir apparent to the throne of Mahishmati, finds his life and relationships endangered as his adoptive brother Bhallaladeva conspires to claim the throne.',
        'director':'S.S. Rajamouli',
        'streaming':'Netflix, Diney+ Hotstar & Sony Liv',
        'writers':'Vijayendra PrasadS.S, RajamouliC.H & Vijay Kumar',
        'index':5,

    },
]